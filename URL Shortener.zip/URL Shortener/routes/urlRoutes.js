const express = require('express');
const router = express.Router();
const Url = require('../models/Url');
const { nanoid } = require('nanoid');
const QRCode = require('qrcode');
const rateLimit = require('express-rate-limit');
require('dotenv').config();

const baseUrl = process.env.BASE_URL || 'http://localhost:5000';

// Rate limiter
const limiter = rateLimit({
  windowMs: 60 * 1000,
  max: 10
});

// GET / → homepage
router.get('/', (req, res) => {
  res.render('index', { shortUrl: null, qrCode: null });
});

// POST /shorten → generate short URL
// POST Route to shorten URL
app.post('/shorten', limiter, async (req, res) => {
  const { originalUrl, expiresAt } = req.body;

  if (!originalUrl) {
    return res.status(400).send('URL is required');
  }

  // Generate a shortId using nanoid
  const shortId = nanoid(7);
  const shortUrl = `${baseUrl}/${shortId}`; // Construct the full short URL

  if (!shortUrl) {
    return res.status(400).send('Error generating short URL');
  }

  try {
    // Check if the shortUrl already exists
    const existingUrl = await Url.findOne({ shortUrl });

    if (existingUrl) {
      return res.status(400).send('Short URL already exists');
    }

    // Create a new URL document
    const newUrl = new Url({
      originalUrl,
      shortId,
      shortUrl, // Ensure shortUrl is correctly generated
      expiresAt: expiresAt ? new Date(expiresAt) : undefined,
    });

    // Save to MongoDB
    await newUrl.save();

    // Generate a QR code for the short URL
    const qr = await QRCode.toDataURL(shortUrl);

    // Send the response with the short URL and QR code
    res.render('index', { shortUrl, qrCode: qr });
  } catch (err) {
    console.error('❌ Error while shortening:', err);
    res.status(500).send('Server error');
  }
});





// GET /:shortId → redirect to original URL
router.get('/:shortId', async (req, res) => {
  const { shortId } = req.params;

  try {
    const url = await Url.findOne({ shortId });

    if (!url) return res.status(404).send('URL not found');
    if (url.expiresAt && new Date() > url.expiresAt) {
      return res.status(410).send('This short URL has expired.');
    }

    url.clicks++;
    await url.save();

    res.redirect(url.originalUrl);
  } catch (err) {
    res.status(500).send('Server error');
  }
});

// GET /admin/view → admin dashboard
router.get('/admin/view', async (req, res) => {
  try {
    const urls = await Url.find().sort({ createdAt: -1 });
    res.render('admin', { urls });
  } catch (err) {
    res.status(500).send('Server error');
  }
});

module.exports = router;
